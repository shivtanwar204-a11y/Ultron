package com.shiv.ultron

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

class UltronAccess : AccessibilityService() {
    companion object { var inst: UltronAccess? = null }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun stroke(p: Path, ms: Long) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        dispatchGesture(g, null, null)
    }

    fun tap(x: Float, y: Float) = stroke(Path().apply { moveTo(x, y) }, 60)
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float) =
        stroke(Path().apply { moveTo(x1, y1); lineTo(x2, y2) }, 300)
    fun back() { performGlobalAction(GLOBAL_ACTION_BACK) }
    fun home() { performGlobalAction(GLOBAL_ACTION_HOME) }
    fun recents() { performGlobalAction(GLOBAL_ACTION_RECENTS) }
    fun open(i: Intent) { startActivity(i) }
}
