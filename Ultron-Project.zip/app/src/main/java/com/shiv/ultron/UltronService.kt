package com.shiv.ultron

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.hypot

class UltronService : LifecycleService() {

    companion object { const val VOICE = "TDTTIZEngvvWARkECefs" }

    private val main = Handler(Looper.getMainLooper())
    private val http = OkHttpClient()
    private lateinit var prefs: SharedPreferences
    private var landmarker: HandLandmarker? = null
    private var sr: SpeechRecognizer? = null
    private var player: MediaPlayer? = null
    @Volatile private var speaking = false
    private val trail = ArrayDeque<Triple<Long, Float, Float>>()
    private var lastAct = 0L

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("u", MODE_PRIVATE)
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("u", "Ultron", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "u").setContentTitle("Ultron active")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        ServiceCompat.startForeground(
            this, 1, n,
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        )
        try {
            val o = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
                .setNumHands(1).setRunningMode(RunningMode.IMAGE).build()
            landmarker = HandLandmarker.createFromOptions(this, o)
        } catch (e: Exception) { }
        startCamera()
        again(300)
        say("Ultron online.")
    }

    // ---------- HAND ----------
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val provider = f.get()
            val a = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888).build()
            a.setAnalyzer(Executors.newSingleThreadExecutor()) { analyze(it) }
            provider.unbindAll()
            provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, a)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(p: ImageProxy) {
        try {
            val bmp = p.toBitmap()
            val m = Matrix().apply { postRotate(p.imageInfo.rotationDegrees.toFloat()) }
            val rot = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            val res = landmarker?.detect(BitmapImageBuilder(rot).build())
            val hand = res?.landmarks()?.firstOrNull()
            if (hand == null) trail.clear() else handle(hand)
        } catch (e: Exception) {
        } finally { p.close() }
    }

    private fun d(a: NormalizedLandmark, b: NormalizedLandmark) = hypot(a.x() - b.x(), a.y() - b.y())

    private fun handle(h: List<NormalizedLandmark>) {
        val acc = UltronAccess.inst ?: return
        val now = SystemClock.uptimeMillis()
        val dm = resources.displayMetrics
        val sw = dm.widthPixels.toFloat()
        val sh = dm.heightPixels.toFloat()
        val palm = d(h[0], h[9])

        // mutthi = back
        val fist = listOf(8 to 6, 12 to 10, 16 to 14, 20 to 18).all { d(h[it.first], h[0]) < d(h[it.second], h[0]) }
        if (fist) {
            if (now - lastAct > 1500) { lastAct = now; acc.back() }
            trail.clear(); return
        }
        // pinch = tap
        if (d(h[4], h[8]) < palm * 0.25f) {
            if (now - lastAct > 900) {
                lastAct = now
                val nx = (1f - (h[4].x() + h[8].x()) / 2f - 0.2f) / 0.6f
                val ny = ((h[4].y() + h[8].y()) / 2f - 0.2f) / 0.6f
                acc.tap(nx.coerceIn(0f, 1f) * sw, ny.coerceIn(0f, 1f) * sh)
            }
            trail.clear(); return
        }
        // swipe
        trail.addLast(Triple(now, 1f - h[0].x(), h[0].y()))
        while (trail.isNotEmpty() && now - trail.first().first > 350) trail.removeFirst()
        if (trail.size >= 3 && now - lastAct > 800) {
            val dx = trail.last().second - trail.first().second
            val dy = trail.last().third - trail.first().third
            if (abs(dy) > 0.22f && abs(dy) > abs(dx)) {
                lastAct = now; trail.clear()
                if (dy < 0) acc.swipe(sw / 2, sh * 0.7f, sw / 2, sh * 0.3f)
                else acc.swipe(sw / 2, sh * 0.3f, sw / 2, sh * 0.7f)
            } else if (abs(dx) > 0.28f && abs(dx) > abs(dy)) {
                lastAct = now; trail.clear()
                if (dx > 0) acc.swipe(sw * 0.2f, sh / 2, sw * 0.8f, sh / 2)
                else acc.swipe(sw * 0.8f, sh / 2, sw * 0.2f, sh / 2)
            }
        }
    }

    // ---------- VOICE IN ----------
    private val listenRun = Runnable {
        if (!speaking) {
            if (sr == null) {
                sr = SpeechRecognizer.createSpeechRecognizer(this)
                sr!!.setRecognitionListener(object : RecognitionListener {
                    override fun onResults(r: Bundle?) {
                        r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onHeard(it) }
                        again()
                    }
                    override fun onError(e: Int) { again(600) }
                    override fun onReadyForSpeech(p: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(v: Float) {}
                    override fun onBufferReceived(b: ByteArray?) {}
                    override fun onEndOfSpeech() {}
                    override fun onPartialResults(p: Bundle?) {}
                    override fun onEvent(t: Int, p: Bundle?) {}
                })
            }
            sr!!.cancel()
            sr!!.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-IN")
            })
        }
    }

    private fun again(ms: Long = 400) { main.removeCallbacks(listenRun); main.postDelayed(listenRun, ms) }

    private fun onHeard(text: String) {
        val t = text.lowercase()
        if (!(t.contains("ultron") || t.contains("altron") || t.contains("ultran"))) return
        val c = t.replace("ultron", "").replace("altron", "").replace("ultran", "").trim()
        val w = c.split(" ", ",", ".").filter { it.isNotBlank() }
        val acc = UltronAccess.inst
        val dm = resources.displayMetrics
        val sw = dm.widthPixels.toFloat(); val sh = dm.heightPixels.toFloat()
        fun any(vararg k: String) = k.any { w.contains(it) }
        when {
            any("open", "kholo", "khol", "launch", "start") -> {
                val q = w.filterNot { it in setOf("open", "kholo", "khol", "launch", "start", "karo", "please", "the", "app", "ko") }
                    .joinToString("")
                if (openApp(q)) say("Theek hai.") else say("App nahi mila.")
            }
            any("back", "peeche", "wapas") -> { acc?.back(); say("Theek hai.") }
            any("home") -> { acc?.home(); say("Theek hai.") }
            any("recent", "recents") -> { acc?.recents(); say("Theek hai.") }
            any("down", "neeche") -> { acc?.swipe(sw / 2, sh * 0.7f, sw / 2, sh * 0.3f) }
            any("up", "upar") -> { acc?.swipe(sw / 2, sh * 0.3f, sw / 2, sh * 0.7f) }
            c.isNotBlank() -> ask(c)
        }
    }

    private fun openApp(q: String): Boolean {
        if (q.isBlank()) return false
        val pm = packageManager
        val list = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = list.firstOrNull {
            val l = it.loadLabel(pm).toString().lowercase().replace(" ", "")
            l.isNotBlank() && (q.contains(l) || l.contains(q))
        } ?: return false
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        UltronAccess.inst?.open(i) ?: startActivity(i)
        return true
    }

    // ---------- BRAIN (Claude) ----------
    private fun ask(q: String) {
        val key = prefs.getString("cl", "") ?: ""
        if (key.isBlank()) return
        Thread {
            try {
                val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 150)
                    .put("system", "You are ULTRON: calm, powerful, slightly sarcastic AI assistant. Reply in Hinglish, maximum 2 short sentences.")
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", q)))
                val req = Request.Builder().url("https://api.anthropic.com/v1/messages")
                    .header("x-api-key", key).header("anthropic-version", "2023-06-01")
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                http.newCall(req).execute().use { r ->
                    val txt = JSONObject(r.body!!.string()).getJSONArray("content").getJSONObject(0).getString("text")
                    say(txt)
                }
            } catch (e: Exception) { }
        }.start()
    }

    // ---------- VOICE OUT (ElevenLabs) ----------
    private fun say(t: String) {
        val key = prefs.getString("el", "") ?: ""
        if (key.isBlank()) return
        speaking = true
        Thread {
            try {
                val body = JSONObject().put("text", t).put("model_id", "eleven_multilingual_v2")
                val req = Request.Builder()
                    .url("https://api.elevenlabs.io/v1/text-to-speech/$VOICE?output_format=mp3_44100_128")
                    .header("xi-api-key", key)
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                http.newCall(req).execute().use { r ->
                    if (!r.isSuccessful) { speaking = false; again(); return@use }
                    val f = File(cacheDir, "v.mp3")
                    f.writeBytes(r.body!!.bytes())
                    main.post {
                        try {
                            player?.release()
                            player = MediaPlayer().apply {
                                setDataSource(f.path)
                                setOnCompletionListener { speaking = false; again() }
                                prepare(); start()
                            }
                        } catch (e: Exception) { speaking = false; again() }
                    }
                }
            } catch (e: Exception) { speaking = false; again() }
        }.start()
    }

    override fun onDestroy() {
        main.removeCallbacks(listenRun)
        sr?.destroy(); player?.release(); landmarker?.close()
        super.onDestroy()
    }
}
