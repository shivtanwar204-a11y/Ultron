package com.shiv.ultron

import android.Manifest
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val perms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { r ->
        if (r[Manifest.permission.CAMERA] == true && r[Manifest.permission.RECORD_AUDIO] == true) {
            ContextCompat.startForegroundService(this, Intent(this, UltronService::class.java))
            Toast.makeText(this, "Ultron chalu. Ab 'Ultron, open YouTube' bolo.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Camera aur mic permission zaroori hai", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("u", MODE_PRIVATE)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
            setBackgroundColor(Color.BLACK)
        }
        fun tv(t: String, s: Float) = TextView(this).apply { text = t; setTextColor(Color.RED); textSize = s; setPadding(0, 16, 0, 16) }
        fun et(h: String, k: String) = EditText(this).apply {
            hint = h; setText(p.getString(k, ""))
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        fun bt(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }

        val el = et("ElevenLabs API key", "el")
        val cl = et("Claude API key", "cl")

        col.addView(tv("ULTRON", 32f))
        col.addView(tv("Android 16: Settings > Apps > Ultron > 3 dots > 'Allow restricted settings', phir Accessibility ON karo.", 13f))
        col.addView(el)
        col.addView(cl)
        col.addView(bt("1. Accessibility ON karo") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        col.addView(bt("2. START ULTRON") {
            p.edit().putString("el", el.text.toString().trim()).putString("cl", cl.text.toString().trim()).apply()
            perms.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
        })
        col.addView(bt("STOP") { stopService(Intent(this, UltronService::class.java)) })
        col.addView(tv("Hath: pinch = tap, mutthi = back, hath upar/neeche/left/right = swipe.\nAwaaz: 'Ultron, open YouTube', 'Ultron, go back', 'Ultron, scroll down', 'Ultron, home'. Baaki kuch bhi pucho to Ultron jawab dega.", 14f))
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
